# MeuCursoIdeal
Avaliador de cursos SENAC utilizando IA
